package model;

public class Estoque {

	private int qta;

	public int getQta() {
		return qta;
	}

	public void setQta(int qta) {
		this.qta = qta;
	}

}
