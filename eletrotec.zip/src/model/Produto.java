package model;

public class Produto {

	private String nome;

	private int polegada;

	private double preco_unitario;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getPolegada() {
		return polegada;
	}

	public void setPolegada(int polegada) {
		this.polegada = polegada;
	}

	public double getPreco_unitario() {
		return preco_unitario;
	}

	public void setPreco_unitario(double preco_unitario) {
		this.preco_unitario = preco_unitario;
	}

}
