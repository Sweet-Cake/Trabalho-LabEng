package model;

public class ItemPedido {

	private int qta;

	private int preco_produto;

	public int getQta() {
		return qta;
	}

	public void setQta(int qta) {
		this.qta = qta;
	}

	public int getPreco_produto() {
		return preco_produto;
	}

	public void setPreco_produto(int preco_produto) {
		this.preco_produto = preco_produto;
	}

}
