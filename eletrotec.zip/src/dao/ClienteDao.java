package dao;

import java.util.List;

import model.Cliente;

public class ClienteDao implements IClienteDao {

	@Override
	public void insert(Cliente cliente) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Cliente> select() {
		// TODO Auto-generated method stub
		return null;
	}

}
