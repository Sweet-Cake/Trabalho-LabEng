package dao;

import java.util.List;

import model.Utensilio;

public class UtensilioDao implements IUtensilioDao {

	@Override
	public void insert(Utensilio person) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Utensilio> select() {
		// TODO Auto-generated method stub
		return null;
	}

}
