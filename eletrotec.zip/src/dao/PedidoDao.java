package dao;

import java.util.List;

import model.Pedido;

public class PedidoDao implements IPedidoDao {

	@Override
	public void insert(Pedido pedido) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Pedido> select() {
		// TODO Auto-generated method stub
		return null;
	}

}
