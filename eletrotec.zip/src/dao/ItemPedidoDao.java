package dao;

import java.util.List;

import model.ItemPedido;

public class ItemPedidoDao implements IItemPedidoDao {

	@Override
	public void insert(ItemPedido itemPedido) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<ItemPedido> select() {
		// TODO Auto-generated method stub
		return null;
	}

}
