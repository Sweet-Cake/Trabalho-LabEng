package dao;

import java.util.List;

import model.UtensilioProduto;

public class UtensilioProdutoDao implements IUtensilioProdutoDao {

	@Override
	public void insert(UtensilioProduto utensilioProduto) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<UtensilioProduto> select() {
		// TODO Auto-generated method stub
		return null;
	}

}
