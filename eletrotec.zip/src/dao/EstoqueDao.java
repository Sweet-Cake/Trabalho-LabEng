package dao;

import java.util.List;

import model.Estoque;

public class EstoqueDao implements IEstoqueDao {

	@Override
	public void insert(Estoque estoque) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Estoque> select() {
		// TODO Auto-generated method stub
		return null;
	}

}
